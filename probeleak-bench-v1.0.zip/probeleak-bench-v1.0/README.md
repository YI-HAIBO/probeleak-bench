# ProbeLeak-Bench v1.0

A frozen probe suite and evidence artifact set for measuring credential
leakage in the reasoning (chain-of-thought) channel of LLM-based database
agents.

This bundle accompanies the manuscript:

> **Measuring the Reasoning-Channel Blind Spot in LLM Database Agents:
> Forensic Evidence of Credential Leakage and Defense Composition**
> Haibo Yi, Shenzhen Polytechnic University.

## Contents

| Path | Contents |
|---|---|
| `probes/probes.json` | The 35 frozen attack probes with class, protocol family, schema-dependence and difficulty-tier metadata |
| `probes/probes.jsonl` | Same probes, one JSON object per line |
| `framework/` | The `llm_attack_eval` experiment framework (corpus, engine, judge, report, CLI) |
| `experiments/` | The experiment scripts that produced the paper's numbers; gateway authenticators are read from `GATEWAY_API_KEY` |
| `artifacts/` | The stored JSON result artifacts the paper's numbers are computed from |
| `docs/provenance.md` | Mapping of every reported value to its JSON artifact field |
| `MANIFEST.sha256` | SHA-256 of every shipped file |

## Quick start

```bash
pip install -e .                      # or put framework/ on PYTHONPATH
export GATEWAY_API_KEY=...            # only for re-running real-model scripts
python -c "import json; \
print(len(json.load(open('probes/probes.json'))['probes']))"   # 35
```

Every number in the manuscript is regenerated from `artifacts/` by the
report and figure generators; a regeneration that differs from the stored
artifact fails loudly. Simulation experiments use fixed seeds and are
exactly reproducible.

## What is and is not re-runnable

- The probe suite, framework, all simulation experiments, and every derived
  statistic in the paper are re-runnable from this bundle.
- The real-model experiments target third-party hosted gateways whose
  credentials are not released (the primary model is identified only under
  a disclosure agreement with the operator). The request scripts are
  shipped, so the protocol can be re-run against any gateway that exposes
  a reasoning channel, by setting `GATEWAY_API_KEY`.
- **No-credential synthetic run.** The framework ships a deterministic
  `SyntheticModel` backend plus a 15-key synthetic honeypot. Run the full
  probe-to-verdict pipeline offline, with no API key and no network:

  ```bash
  python experiments/p2_synthetic_demo.py
  ```

  This replays the probe set through the mock reasoning model and reproduces
  the manuscript's channel-separation signature (reasoning-channel leakage
  with a clean final channel), asserting a blind-spot gate. It is a faithful
  harness for the non-credential parts of the pipeline, not a substitute for
  the real-model measurements.

## Ethics and safety

- All credentials in the experiments are **synthetic honeypot keys** marked
  with a `FAKE_` prefix in a dedicated test database. No real customer
  secret and no personally identifiable data appears in any artifact. Key
  values that appear inside `artifacts/` are the synthetic material the
  models were measured on reciting; they are not authenticators.
- The gateway operator was informed of the findings before submission and
  consented to publication.
- The probes are intended for measuring leakage on systems you operate or
  are authorized to test.

## License

- Code (`framework/`, `experiments/`): MIT.
- Probe data (`probes/`) and result artifacts (`artifacts/`):
  CC-BY-4.0.

See `LICENSE.txt`.
