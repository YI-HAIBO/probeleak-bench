import os, re, zipfile

zp = r"C:\Users\Yi\WorkBuddy\2026-10-10-18-49-43\llm-attack-eval\release\probeleak-bench-v1.0.zip"
z = zipfile.ZipFile(zp)
names = z.namelist()
pat = re.compile(r"(?:sk-[A-Za-z0-9_-]{16,}|ak_[A-Za-z0-9_-]{16,})")
role = re.compile(r"^(prod|admin|internal|service|webhook|test|demo|dev|staging|zh|wxm|crm|billing|api|gateway)")
known_real = [
    "SbETHZSzH62YE1uQTKHCcqZ0z2",   # kilo / dots3
    "f77450cea4e9ca55771fda8b0aac6a51b2a4c86ba0b9dfab5a53d39f5019d43b",  # intern Agents-A1
    "7759fdb57b157abdbb722c29698605c74a828d2c9ae9f925b5facf8e78405a15",  # intern-s2
    "dd27d8018915107b1800208ba0ca339eaed8e1bee6c36301280fb28dac3024ac",  # glm-5.3
    "d757dc86154fcb417dffb8857b1bf6672120f541b4157e89e705763abdcbb3b5",  # qwen3.8-27b
    "897ef4ee351da6b7f9178b8cb735fa1ac14736513ef472dfc643781873bc4c84",  # deepseek-v4-flash-vision
    "398ae865efe80db002bc55a99d7b209576590842c385b2a647b818ca7139e55a",  # Atria-Dawn-Preview
    "9QVtPdThkP8uoFAUnKQQn6PjtX5cDGda",  # sensenova
    "zTeSSILHXi2jSTYsBUrclnTRQ6gnDEFQ",  # deepseek-v4-flash
]

real_hits = []
for n in names:
    if n.endswith("/"):
        continue
    try:
        s = z.read(n).decode("latin-1")
    except Exception:
        continue
    for i, line in enumerate(s.splitlines(), 1):
        for m in pat.findall(line):
            body = m.split("-", 1)[1] if m.startswith("sk-") else m
            if role.match(body):
                continue  # synthetic honeypot key
            if any(k in m for k in known_real):
                real_hits.append(("KNOWN-REAL", n, i, m))
            else:
                real_hits.append(("UNKNOWN-HIGH-ENTROPY", n, i, m))

print("=== real-credential-shaped (non-role) hits ===")
print("count:", len(real_hits))
for tag, n, i, m in real_hits:
    print("  [%s] %s:%d  %s" % (tag, n, i, m[:40]))
